# ElevatorCodingChallenge
REST API that utilizes AWS Lambda, DynamoDB and Serverless Framework
